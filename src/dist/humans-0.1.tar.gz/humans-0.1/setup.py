from setuptools import setup

setup(name='humans',
      version='0.1',
      description='Humans of planet earth.',
      author='Brahma',
      author_email='four@faces.com',
      license='MIT',
      keywords=['mammals', 'bipedal', 'sentient'],
      packages=['humans'])
