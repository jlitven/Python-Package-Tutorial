def spout_wisdom():
    print "There's a heaven for a G."
